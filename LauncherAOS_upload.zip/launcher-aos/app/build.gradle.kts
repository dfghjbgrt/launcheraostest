plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.launcheraos.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.launcheraos.launcher"
        minSdk = 21
        targetSdk = 28
        versionCode = 2
        versionName = "0.2.0"
    }
}
