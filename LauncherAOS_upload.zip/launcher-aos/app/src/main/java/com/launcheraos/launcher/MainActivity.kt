package com.launcheraos.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.app.ActivityOptions
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private data class AppEntry(
        val label: String,
        val packageName: String,
        val icon: android.graphics.drawable.Drawable?
    )

    private val apps = mutableListOf<AppEntry>()
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var widgetArea: LinearLayout
    private lateinit var search: EditText
    private val prefs by lazy { getSharedPreferences("launcher_aos", Context.MODE_PRIVATE) }
    private val appWidgetHost by lazy { AppWidgetHost(this, APPWIDGET_HOST_ID) }
    private val appWidgetManager by lazy { AppWidgetManager.getInstance(this) }
    private var drawerOpen = false

    companion object {
        private const val APPWIDGET_HOST_ID = 0xA05
        private const val REQUEST_PICK_WIDGET = 4101
        private const val REQUEST_BIND_WIDGET = 4102
        private const val REQUEST_CONFIGURE_WIDGET = 4103
        private const val KEY_PENDING_WIDGET = "pending_widget_id"
        private const val FOLDER_PREFIX = "folder_"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        if (::root.isInitialized) showHome()
        try { appWidgetHost.startListening() } catch (_: Exception) {}
    }

    override fun onPause() {
        try { appWidgetHost.stopListening() } catch (_: Exception) {}
        super.onPause()
    }

    private fun applySystemBars() {
        window.statusBarColor = Color.rgb(245, 247, 251)
        window.navigationBarColor = Color.rgb(245, 247, 251)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
    }

    private fun loadApps() {
        apps.clear()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        resolved.mapNotNull { item ->
            val info = item.activityInfo ?: return@mapNotNull null
            if (info.packageName == packageName) return@mapNotNull null
            AppEntry(item.loadLabel(pm).toString(), info.packageName, item.loadIcon(pm))
        }.distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .forEach { apps.add(it) }
    }

    private fun showHome() {
        drawerOpen = false
        buildBase("Launcher AOS", "Лёгкий Android · с элементами iOS")
        val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val clock = TextView(this).apply {
            text = dateFormat.format(Date())
            textSize = 46f
            setTextColor(Color.rgb(30, 37, 52))
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(dp(4), dp(18), dp(4), 0)
        }
        root.addView(clock)
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            textSize = 14f
            setTextColor(Color.rgb(105, 112, 128))
            setPadding(dp(6), 0, dp(4), dp(18))
        }
        root.addView(date)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(actionButton("Приложения") { showDrawer() }, weightedButtonParams())
        actions.addView(actionButton("Виджеты +") { pickWidget() }, weightedButtonParams())
        actions.addView(actionButton("Обои") { chooseWallpaper() }, weightedButtonParams())
        root.addView(actions)

        val folderNames = getFolderNames()
        if (folderNames.isNotEmpty()) {
            sectionTitle("Папки")
            val folderRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            folderNames.forEach { name ->
                val count = getFolderPackages(name).size
                val tile = TextView(this).apply {
                    text = "▦\n$name\n$count прилож."
                    gravity = Gravity.CENTER
                    textSize = 12f
                    setTextColor(Color.rgb(45, 53, 72))
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(Color.WHITE, 18)
                    isClickable = true
                    setOnClickListener { openFolder(name) }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle(name)
                            .setItems(arrayOf("Изменить содержимое", "Удалить папку")) { _, which ->
                                if (which == 0) editFolder(name) else deleteFolder(name)
                            }.show()
                        true
                    }
                }
                folderRow.addView(tile, LinearLayout.LayoutParams(0, dp(88), 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                })
            }
            root.addView(folderRow)
        }

        sectionTitle("Избранное")
        val pinned = apps.filter { isPinned(it.packageName) }.take(12)
        val homeApps = if (pinned.isNotEmpty()) pinned else apps.take(8)
        addAppGrid(homeApps)

        sectionTitle("Виджеты")
        widgetArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(widgetArea, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        restoreWidgets()

        root.addView(actionButton("Настройки лаунчера") { showSettings() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
    }

    private fun showDrawer(filter: String = "") {
        drawerOpen = true
        buildBase("Приложения", "${apps.size} приложений")
        search = EditText(this).apply {
            hint = "Поиск приложений"
            singleLine = true
            textSize = 16f
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = rounded(Color.WHITE, 24)
            setText(filter)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        appGrid = GridLayout(this).apply { columnCount = 4 }
        val scroll = ScrollView(this).apply { addView(appGrid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        renderApps(filter)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(actionButton("＋ Создать большую папку") { createFolderPicker() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
        root.addView(actionButton("На главный экран") { showHome() },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5) })
    }

    private fun renderApps(filter: String) {
        if (!::appGrid.isInitialized) return
        appGrid.removeAllViews()
        apps.filter { it.label.contains(filter, true) }.forEach { app ->
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(105)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(4), dp(3), dp(4))
            }
            appGrid.addView(appTile(app), params)
        }
    }

    private fun addAppGrid(entries: List<AppEntry>) {
        val grid = GridLayout(this).apply { columnCount = 4 }
        entries.forEach { app ->
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(104)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(4), dp(3), dp(4))
            }
            grid.addView(appTile(app), params)
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun appTile(app: AppEntry): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(5), dp(3), dp(5))
            background = rounded(Color.WHITE, 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { launchApp(app, this) }
            setOnLongClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(app.label)
                    .setItems(arrayOf("Открыть", "Добавить в папку", "Закрепить на главном экране", "Информация о приложении")) { _, which ->
                        when (which) {
                            0 -> launchApp(app, this)
                            1 -> addAppToFolder(app)
                            2 -> { setPinned(app.packageName, true); if (!drawerOpen) showHome() }
                            3 -> openAppInfo(app.packageName)
                        }
                    }.show()
                true
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
        val label = TextView(this).apply {
            text = app.label
            textSize = 11f
            maxLines = 2
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 41, 55))
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(label, LinearLayout.LayoutParams(-1, dp(36)))
        return box
    }

    private fun launchApp(app: AppEntry, source: View) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
            if (android.os.Build.VERSION.SDK_INT >= 16) {
                val rect = android.graphics.Rect()
                source.getGlobalVisibleRect(rect)
                val options = ActivityOptions.makeScaleUpAnimation(
                    source, 0, 0, maxOf(1, rect.width()), maxOf(1, rect.height())
                )
                startActivity(intent, options.toBundle())
            } else startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createFolderPicker() {
        if (apps.isEmpty()) return
        val selected = BooleanArray(apps.size)
        AlertDialog.Builder(this)
            .setTitle("Выберите приложения для папки")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), selected) { _, which, checked ->
                selected[which] = checked
            }
            .setPositiveButton("Продолжить") { _, _ ->
                val chosen = apps.filterIndexed { index, _ -> selected[index] }
                if (chosen.isEmpty()) return@setPositiveButton
                askFolderName(chosen.map { it.packageName }.toSet())
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askFolderName(packages: Set<String>) {
        val input = EditText(this).apply { hint = "Например, Игры"; setSingleLine(true) }
        AlertDialog.Builder(this)
            .setTitle("Название большой папки")
            .setView(input)
            .setPositiveButton("Создать") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "Новая папка" }
                saveFolder(name, packages)
                if (::root.isInitialized) showHome()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun addAppToFolder(app: AppEntry) {
        val folders = getFolderNames()
        if (folders.isEmpty()) {
            askFolderName(setOf(app.packageName))
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Добавить ${app.label} в папку")
            .setItems((folders + "＋ Новая папка").toTypedArray()) { _, which ->
                if (which == folders.size) askFolderName(setOf(app.packageName))
                else {
                    val name = folders[which]
                    val contents = getFolderPackages(name).toMutableSet()
                    contents.add(app.packageName)
                    saveFolder(name, contents)
                }
            }.show()
    }

    private fun openFolder(name: String) {
        val entries = getFolderPackages(name).mapNotNull { pkg -> apps.find { it.packageName == pkg } }
        val grid = GridLayout(this).apply { columnCount = 4 }
        entries.forEach { app ->
            grid.addView(appTile(app), GridLayout.LayoutParams().apply {
                width = dp(76); height = dp(100); setMargins(dp(2), dp(2), dp(2), dp(2))
            })
        }
        val scroll = ScrollView(this).apply { addView(grid) }
        AlertDialog.Builder(this).setTitle(name).setView(scroll)
            .setPositiveButton("Готово", null)
            .setNeutralButton("Изменить") { _, _ -> editFolder(name) }
            .show()
    }

    private fun editFolder(name: String) {
        val selected = BooleanArray(apps.size)
        val current = getFolderPackages(name)
        apps.forEachIndexed { index, app -> selected[index] = current.contains(app.packageName) }
        AlertDialog.Builder(this)
            .setTitle("Содержимое: $name")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), selected) { _, which, checked ->
                selected[which] = checked
            }
            .setPositiveButton("Сохранить") { _, _ ->
                saveFolder(name, apps.filterIndexed { i, _ -> selected[i] }.map { it.packageName }.toSet())
                showHome()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun deleteFolder(name: String) {
        prefs.edit().remove(FOLDER_PREFIX + name).apply()
        showHome()
    }

    private fun getFolderNames(): List<String> =
        prefs.all.keys.filter { it.startsWith(FOLDER_PREFIX) }.map { it.removePrefix(FOLDER_PREFIX) }.sorted()

    private fun getFolderPackages(name: String): Set<String> =
        prefs.getStringSet(FOLDER_PREFIX + name, emptySet())?.toSet() ?: emptySet()

    private fun saveFolder(name: String, packages: Set<String>) {
        prefs.edit().putStringSet(FOLDER_PREFIX + name, packages).apply()
    }

    private fun isPinned(pkg: String) = prefs.getBoolean("pin_$pkg", false)
    private fun setPinned(pkg: String, value: Boolean) { prefs.edit().putBoolean("pin_$pkg", value).apply() }

    private fun pickWidget() {
        try {
            val appWidgetId = appWidgetHost.allocateAppWidgetId()
            prefs.edit().putInt(KEY_PENDING_WIDGET, appWidgetId).apply()
            val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK)
            pick.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            startActivityForResult(pick, REQUEST_PICK_WIDGET)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть выбор виджета", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy activity result API supports older Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val widgetId = prefs.getInt(KEY_PENDING_WIDGET, -1)
        if (requestCode == REQUEST_PICK_WIDGET || requestCode == REQUEST_BIND_WIDGET) {
            if (resultCode != RESULT_OK || widgetId < 0) {
                if (widgetId >= 0) appWidgetHost.deleteAppWidgetId(widgetId)
                prefs.edit().remove(KEY_PENDING_WIDGET).apply()
                return
            }
            val info = appWidgetManager.getAppWidgetInfo(widgetId)
            if (info == null) {
                finishWidgetSetup(widgetId)
                return
            }
            if (info.configure != null) {
                val configure = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                configure.component = info.configure
                configure.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                startActivityForResult(configure, REQUEST_CONFIGURE_WIDGET)
            } else finishWidgetSetup(widgetId)
        } else if (requestCode == REQUEST_CONFIGURE_WIDGET) {
            if (resultCode == RESULT_OK && widgetId >= 0) finishWidgetSetup(widgetId)
            else {
                if (widgetId >= 0) appWidgetHost.deleteAppWidgetId(widgetId)
                prefs.edit().remove(KEY_PENDING_WIDGET).apply()
            }
        }
    }

    private fun finishWidgetSetup(widgetId: Int) {
        val ids = prefs.getStringSet("widget_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(widgetId.toString())
        prefs.edit().putStringSet("widget_ids", ids).remove(KEY_PENDING_WIDGET).apply()
        showHome()
    }

    private fun restoreWidgets() {
        if (!::widgetArea.isInitialized) return
        val ids = prefs.getStringSet("widget_ids", emptySet()) ?: emptySet()
        if (ids.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Здесь появятся ваши Android-виджеты"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.GRAY)
                setPadding(dp(12), dp(14), dp(12), dp(14))
            }
            widgetArea.addView(empty)
            return
        }
        ids.forEach { value ->
            val id = value.toIntOrNull() ?: return@forEach
            try {
                val hostView: AppWidgetHostView = appWidgetHost.createView(this, id, appWidgetManager.getAppWidgetInfo(id))
                widgetArea.addView(hostView, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { bottomMargin = dp(8) })
                hostView.setOnLongClickListener {
                    AlertDialog.Builder(this).setMessage("Удалить этот виджет с главного экрана?")
                        .setPositiveButton("Удалить") { _, _ ->
                            appWidgetHost.deleteAppWidgetId(id)
                            val updated = ids.toMutableSet()
                            updated.remove(value)
                            prefs.edit().putStringSet("widget_ids", updated).apply()
                            showHome()
                        }.setNegativeButton("Отмена", null).show()
                    true
                }
            } catch (_: Exception) {}
        }
    }

    private fun chooseWallpaper() {
        try {
            startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
        } catch (_: Exception) {
            Toast.makeText(this, "Откройте системные настройки обоев", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        buildBase("Настройки", "Персонализация Launcher AOS")
        addSettingRow("Выбрать обои", "Системная галерея обоев") { chooseWallpaper() }
        addSettingRow("Приложение по умолчанию", "Открыть настройки главного экрана") {
            try { startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)) }
            catch (_: Exception) {
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            }
        }
        addSettingRow("Добавить виджет", "Стандартные Android App Widgets") { pickWidget() }
        addSettingRow("Управление приложениями", "Поиск, закрепление и создание папок") { showDrawer() }
        addSettingRow("Информация о приложении", "Launcher AOS · версия 0.2.0") {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")))
        }
        root.addView(actionButton("Назад") { showHome() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
    }

    private fun addSettingRow(title: String, subtitle: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(Color.WHITE, 16)
            isClickable = true
            setOnClickListener { action() }
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 16f; setTextColor(Color.rgb(35, 41, 55))
            })
            addView(TextView(this@MainActivity).apply {
                text = subtitle; textSize = 12f; setTextColor(Color.GRAY)
            })
        }
        root.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(9) })
    }

    private fun sectionTitle(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(37, 44, 60))
            setPadding(dp(4), dp(17), dp(4), dp(8))
        })
    }

    private fun buildBase(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = title
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(28, 35, 50))
            setPadding(dp(2), dp(6), dp(2), 0)
        })
        root.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(dp(4), 0, dp(4), dp(12))
        })
    }

    private fun actionButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.rgb(42, 51, 70))
            background = rounded(Color.WHITE, 22)
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun weightedButtonParams() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        setMargins(dp(3), 0, dp(3), 0)
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$pkg")))
        } catch (_: Exception) {}
    }
}
